#!/usr/bin/env bash
# =============================================================
# deploy_pii_prefilters.sh
#
# Installs language-specific PII prefilter .cfg files (name,
# address, numeric) into an Eduction resource type's prefilter/
# folder, and compiles the plain-text wordlists into the .dpf
# dictionary files those .cfg files reference via ResourceFile=.
#
# Usage:
#   sudo ./deploy_pii_prefilters.sh <EDUCTION_RESOURCE_DIR> <lang>
#
#   EDUCTION_RESOURCE_DIR e.g. /opt/nifi/nifi-current/eduction/pci
#   lang                  one of: en fr de cs he
#
# Requires the IDOL dictionary compiler (dictionarycompiler /
# expert tool that ships with your IDOL/Eduction distribution) to
# be on PATH as `dictionarycompiler` - adjust DICT_COMPILER below
# to match your installation if the binary name/path differs.
# =============================================================
set -euo pipefail

RESOURCE_DIR="${1:?Usage: $0 <eduction_resource_dir> <lang: en|fr|de|cs|he>}"
LANG_CODE="${2:?Usage: $0 <eduction_resource_dir> <lang: en|fr|de|cs|he>}"
KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DICT_COMPILER="${DICT_COMPILER:-dictionarycompiler}"

PREFILTER_DIR="${RESOURCE_DIR}/prefilter"
mkdir -p "${PREFILTER_DIR}"

echo "== Installing PII prefilters for lang=${LANG_CODE} into ${PREFILTER_DIR}"

# 1. Always install the shared numeric prefilter
cp -f "${KIT_DIR}/general_numeric.cfg" "${PREFILTER_DIR}/general_numeric.cfg"

# 2. Install language-specific name + address cfg files
case "${LANG_CODE}" in
  en|fr|de|cs|he) ;;
  *) echo "Unsupported lang '${LANG_CODE}'. Use one of: en fr de cs he" >&2; exit 1 ;;
esac

cp -f "${KIT_DIR}/name/name_${LANG_CODE}.cfg" "${PREFILTER_DIR}/name_${LANG_CODE}.cfg"
cp -f "${KIT_DIR}/address/address_${LANG_CODE}.cfg" "${PREFILTER_DIR}/address_${LANG_CODE}.cfg"

# 3. Compile the wordlists this language's cfg files reference and
#    drop the resulting .dpf next to the cfg files.
compile_wordlist () {
  local txt="$1" dpf_name="$2"
  if ! command -v "${DICT_COMPILER}" &>/dev/null; then
    echo "   WARNING: '${DICT_COMPILER}' not found on PATH - copying source"
    echo "            wordlist only. Compile it manually into"
    echo "            ${PREFILTER_DIR}/${dpf_name} before restarting Eduction."
    cp -f "${txt}" "${PREFILTER_DIR}/${dpf_name%.dpf}.txt"
    return
  fi
  "${DICT_COMPILER}" --input "${txt}" --output "${PREFILTER_DIR}/${dpf_name}"
}

case "${LANG_CODE}" in
  en) compile_wordlist "${KIT_DIR}/wordlists/address_street_markers_en.txt" "address_street_markers_en.dpf" ;;
  fr) compile_wordlist "${KIT_DIR}/wordlists/address_street_markers_fr.txt" "address_street_markers_fr.dpf" ;;
  de) compile_wordlist "${KIT_DIR}/wordlists/address_street_markers_de.txt" "address_street_markers_de.dpf" ;;
  cs) compile_wordlist "${KIT_DIR}/wordlists/address_street_markers_cs.txt" "address_street_markers_cs.dpf" ;;
  he)
    compile_wordlist "${KIT_DIR}/wordlists/given_names_he.txt" "given_names_he.dpf"
    compile_wordlist "${KIT_DIR}/wordlists/address_markers_he.txt" "address_markers_he.dpf"
    ;;
esac

echo "== Done. Disable/re-enable the Eduction controller service (or restart"
echo "   NiFi) so it re-scans ${PREFILTER_DIR}."
