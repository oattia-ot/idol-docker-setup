# PII Prefilter Kit (name / address / numeric) — en, fr, de, cs, he

Eduction prefilters are `.cfg` files, not free-form scripts. Each one
declares its tasks under an `[Eduction]` section, then gives each task
its own section with either:

- `Regex=` — a PCRE-style pattern Eduction scans for, plus
  `WindowCharsBeforeMatch` / `WindowCharsAfterMatch` to define how much
  surrounding text gets passed to the real entity grammar, or
- `ResourceFile=` — a path to a compiled dictionary (`.dpf`) of terms,
  for cases a regex can't express well (name lists, marker words in a
  non-Latin script, etc).

`.dpf` files are **compiled binaries**, not hand-editable text — they're
built from a plain word list using IDOL's dictionary compiler. This kit
ships the plain-text source lists under `wordlists/` and compiles them
for you in the deploy step (or tells you to compile them yourself if
the compiler isn't on the box you're running the script from).

## Layout

```
pii_prefilter_kit/
├── deploy_pii_prefilters.sh
├── general_numeric.cfg          # shared across all languages
├── name/
│   ├── name_en.cfg
│   ├── name_fr.cfg
│   ├── name_de.cfg
│   ├── name_cs.cfg
│   └── name_he.cfg
├── address/
│   ├── address_en.cfg
│   ├── address_fr.cfg
│   ├── address_de.cfg
│   ├── address_cs.cfg
│   └── address_he.cfg
└── wordlists/                    # plain-text sources -> compile to .dpf
    ├── address_street_markers_en.txt
    ├── address_street_markers_fr.txt
    ├── address_street_markers_de.txt
    ├── address_street_markers_cs.txt
    ├── given_names_he.txt
    └── address_markers_he.txt
```

## Deploying

```bash
sudo ./deploy_pii_prefilters.sh /opt/nifi/nifi-current/eduction/pci en
sudo ./deploy_pii_prefilters.sh /opt/nifi/nifi-current/eduction/pci fr
sudo ./deploy_pii_prefilters.sh /opt/nifi/nifi-current/eduction/pci de
sudo ./deploy_pii_prefilters.sh /opt/nifi/nifi-current/eduction/pci cs
sudo ./deploy_pii_prefilters.sh /opt/nifi/nifi-current/eduction/pci he
```

Set `DICT_COMPILER=/path/to/your/dictionary/compiler` if it isn't on
`PATH` under the default name. Repeat per resource type (`doc`, `gov`,
`pbi`, ... ) as needed — the script takes the resource dir as its first
argument.

Then disable/re-enable the Eduction controller service (or restart
NiFi) — these directories are read at controller-enable time, not
per-document.

## Per-language notes

- **English / French / Czech** — all use Latin-script Title-Case
  detection as the base signal (`\p{Lu}`/`\p{L}` already match
  accented capitals like É, Ř, Ž natively). French adds optional
  lowercase particles (`de`, `du`, `des`) and elision (`d'Artagnan`);
  Czech is left close to the English base since particled surnames are
  rare.

- **German** — capitalizes every common noun, not just proper nouns, so
  the same Title-Case regex is much lower-precision here. The German
  name cfg tightens the separator (comma/tab/multi-space rather than a
  single space) to cut down on ordinary-sentence false positives; if
  precision is still too low on free-text documents, prefer switching
  that resource type to a compiled given-names dictionary instead of
  the regex task.

- **Hebrew** — has no case distinction, so the Latin-script pattern
  doesn't transfer at all. The Hebrew name cfg instead combines (a) a
  high-precision regex for honorific-prefixed mentions (Mr./Dr./Adv.
  + name) and (b) a compiled given-names dictionary for recall on
  untitled mentions. Hebrew addresses similarly key off marker words
  (street/boulevard) plus a fallback "Hebrew word(s) + number" pattern.

## Extending

- Add more entries to any `wordlists/*.txt` file, then re-run the
  deploy script to recompile and reinstall.
- Keep one `.cfg` per entity type per language (don't merge name and
  address rules into one file) — it mirrors how the task numbering
  (`PrefilterTask0`, `PrefilterTask1`, ...) is meant to compose, and
  makes it trivial to disable just one signal while debugging.
- `general_numeric.cfg` is intentionally language-agnostic and shared;
  don't fork it per language unless a specific ID/phone/postal format
  needs a narrower window than the default 100/100 chars.
